/* 
==================================================================== |
 [ # ] Script Private Daffa Developer
 [ × ] Dilarang Menjual / membagikan script
 [ @ ] Base Bot bY Anggazyy666_
 [ © ] Thanks to My Friend
       - Barmods
       - Ardhita
       - Cella
   ☎️ t.me/daffadeveloper
=================================================================== |
*/

async function ytdl(url) {
    const fetch = (await import('node-fetch')).default;

    const response = await fetch('https://shinoa.us.kg/api/download/ytdl', {
        method: 'POST',
        headers: {
            'accept': '*/*',
            'api_key': 'free',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            text: url
        })
    });

    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
}

module.exports = { ytdl }