/* 
==================================================================== |
 [ # ] Script Private Daffa Developer
 [ × ] Dilarang Menjual / membagikan script
 [ @ ] Base Bot bY Anggazyy666_
 [ © ] Thanks to My Friend
       - Barmods
       - Ardhita
       - Cella
   ☎️ t.me/daffadeveloper
=================================================================== |
*/

const FormData = require('form-data');
const { fromBuffer } = require('file-type');

/**
 * Upload image to catboxmoe
 * Supported mimetype:
 * - `image/jpeg`
 * - `image/jpg`
 * - `image/png`
 * @param {Buffer} buffer Image Buffer
 */
module.exports = async buffer => {
  // Dynamic import of node-fetch
  const fetchModule = await import('node-fetch');
  const fetch = fetchModule.default; // Accessing the default export

  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");

  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });

  let data = await res.text();
  return data;
}
