/* 
==================================================================== |
 [ # ] Script Private Daffa Developer
 [ × ] Dilarang Menjual / membagikan script
 [ © ] Thanks to My Friend
       - Barmods
       - Dappz
   ☎️ t.me/daffadeveloper
=================================================================== |
*/

global.owner = [
  "6282321593192", //ganti nomor owner
  "" //nomor owner kedua kalo ada
]
global.nomorbot = '6282321593192' // ubah aja
global.urlfoto = 'https://g.top4top.io/p_3331bvp4t1.jpg' //jangan nanti erorr

//=====π=======π=======π========
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})